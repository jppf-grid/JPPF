/*
 * JPPF.
 * Copyright (C) 2005-2016 JPPF Team.
 * http://www.jppf.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jppf.comm.interceptor;

import java.net.Socket;
import java.nio.channels.SocketChannel;

import org.jppf.serialization.SerializationUtils;

/**
 *
 * @author Laurent Cohen
 */
public class DefaultNetworkConnectionInterceptor implements NetworkConnectionInterceptor {
  @Override
  public boolean onAccept(final Socket acceptedSocket) {
    try {
      int n = SerializationUtils.readInt(acceptedSocket.getInputStream());
      if (n != 1) {
        System.out.printf("bad authentication code from client: %d%n", n);
        return false;
      }
      SerializationUtils.writeInt(2, acceptedSocket.getOutputStream());
      acceptedSocket.getOutputStream().flush();
      System.out.printf("successful server authentication for socket %s%n", acceptedSocket);
      return true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean onAccept(final SocketChannel acceptedChannel) {
    try {
      int n = SerializationUtils.readInt(acceptedChannel);
      if (n != 1) {
        System.out.printf("bad authentication code from client: %d%n", n);
        return false;
      }
      SerializationUtils.writeInt(acceptedChannel, 2);
      System.out.printf("successful server authentication for socket channel %s%n", acceptedChannel);
      return true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean onConnect(final Socket connectedSocket) {
    try {
      SerializationUtils.writeInt(1, connectedSocket.getOutputStream());
      connectedSocket.getOutputStream().flush();
      int n = SerializationUtils.readInt(connectedSocket.getInputStream());
      if (n != 2) {
        System.out.printf("bad authentication code from server: %d%n", n);
        return false;
      }
      System.out.printf("successful client authentication for socket %s%n", connectedSocket);
      return true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }
}
