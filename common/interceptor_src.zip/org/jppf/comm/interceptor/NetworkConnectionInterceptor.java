/*
 * JPPF.
 * Copyright (C) 2005-2016 JPPF Team.
 * http://www.jppf.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jppf.comm.interceptor;

import java.net.*;
import java.nio.channels.*;

/**
 * 
 * @author Laurent Cohen
 */
public interface NetworkConnectionInterceptor {
  /**
   * Called when a {@link Socket} is accepted by a {@link ServerSocket}.
   * @param acceptedSocket the socket that was just accepted.
   * @return true to accept the connection false to deny it.
   */
  boolean onAccept(Socket acceptedSocket);

  /**
   * Called when a {@link SocketChannel} is accepted by a {@link ServerSocketChannel}.
   * @param acceptedSocket the socket that was just accepted.
   * @return true to accept the connection false to deny it.
   */
  boolean onAccept(SocketChannel acceptedSocket);

  /**
   * Called when a {@link Socket} is connected.
   * @param connectedSocket the socket that just connected.
   * @return true to accept the connection false to deny it.
   */
  boolean onConnect(Socket connectedSocket);
}
