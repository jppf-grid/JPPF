This patch fixes the bug [3074513 - ClassCastException using JPPFClient(String) constructor]

To appply this patch:

- unzip "jppf-2.2-patch-02.zip"
- to patch a JPPF client: copy "jppf-client.jar" in your client application's library folder,
  this will replace the previous versions of the jar file.
- restart your JPPF application.
