This patch fixes the bugs [3119256 - NPE in AbstractJPPFClassLoader.findResources()]
and [3120933 - Server misses class loading requests].
It is also cumulative with the two previous patches JPPF 2.3 patch 01 and 02.

To apply this patch:

1. unzip "jppf-2.3-patch-03.zip"

2. to patch a JPPF node:
- copy the file "jppf-common-node.jar" in your node's /lib folder,
  this will replace the previous version of the jar file.
- restart the node.

3. to patch a JPPF server/driver:
- copy the files "jppf-common-node.jar", "jppf-common.jar" and "jppf-server.jar" in your server's /lib folder,
  this will replace the previous versions of the jar files.
- restart the server.

4. to patch a JPPF client / admin console:
- copy "jppf-common-node.jar" and "jppf-common.jar" in your client application's library folder,
  this will replace the previous versions of the jar files.
- restart your JPPF application.

This patch also contains the new sources in separate jar files: "jppf-common-node-src.jar", "jppf-common-src.jar" and "jppf-server-src.jar" 