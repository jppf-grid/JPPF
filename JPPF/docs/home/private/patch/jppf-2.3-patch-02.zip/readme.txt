This patch fixes the bug [3110449 - OOM in the node upon large console output]

To appply this patch:

1. unzip "jppf-2.3-patch-02.zip"

2. to patch a JPPF node:
- copy the files "jppf-common-node.jar" in your node's /lib folder,
  this will replace the previous versions of the jar files.
- restart the node.

3. to patch a JPPF server/driver:
- copy the files "jppf-common-node.jar" in your server's /lib folder,
  this will replace the previous version of the jar file.
- restart the server.

4. to patch a JPPF client:
- copy "jppf-common-node.jar" in your client application's library folder,
  this will replace the previous version of the jar file.
- restart your JPPF application.

This patch also contains the new sources in a separate jar file, "jppf-common-node-src.jar"