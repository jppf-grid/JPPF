Patch for bug [3017866 - When connected to multiple drivers, client only uses one]

To appply this patch:

- unzip "jppf-client-2.0-patch-01.zip"
- replace jppf-client.jar anyplace it is used with this new version
- restart the JPPF client
