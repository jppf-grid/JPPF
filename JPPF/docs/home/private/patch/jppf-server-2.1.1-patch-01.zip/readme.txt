Patch for bug [993389 - Nodes are not removed from the console upon dying]

To appply this patch:

- unzip "jppf-server-2.1.1-patch-01.zip"
- copy "jppf-server.jar" into your "<JPPF_Driver>/lib" folder
  this will replace the previous version of the jar
- restart the JPPF driver
