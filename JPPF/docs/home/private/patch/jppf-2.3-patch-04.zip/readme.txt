This patch fixes the bug [3125121 - NPE in DriverJobManagement when in DEBUG mode].
It is not cumulative with any other patch and should be applied AFTER any previous patch (01, 02 or 03).

To apply this patch:

1. unzip "jppf-2.3-patch-04.zip"

2. to patch a JPPF server/driver:
- copy the file "jppf-server.jar" in your server's /lib folder,
  this will replace the previous version of the jar file.
- restart the server.

This patch also contains the new sources in a separate jar files "jppf-server-src.jar" 