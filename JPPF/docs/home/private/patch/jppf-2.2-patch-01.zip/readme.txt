This patch fixes the following bugs:

- 3069849 - Driver hangs on disk overflow operation
- 3071045 - Uncaught OOM in the driver while receiving tasks from a node
- 3071454 - OOME: Direct buffer space, reading large data from a socket

To appply this patch:

- unzip "jppf-2.2-patch-01.zip"
- to patch a JPPF node: copy "jppf-common-node.jar" into your "<JPPF_Node>/folder", to replace the existing jar
- to patch a JPPF driver: copy "jppf-common-node.jar", "jppf-common.jar" and "jppf-server.jar" into your "<JPPF_Driver>/lib" folder,
  this will replace the previous versions of the jar files.
- to patch a JPPF client: copy "jppf-common-node.jar" and "jppf-common.jar" in your client application's library folder,
  this will replace the previous versions of the jar files.
- restart the JPPF driver, nodes, and application.
