var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_dotnet_job_monitor =
[
    [ "DotnetJobMonitor", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_dotnet_job_monitor.html#a0569da36a155ab7db8a7a51655f93a3f", null ],
    [ "DotnetJobMonitor", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_dotnet_job_monitor.html#a244dc68f5bdf7af30cec9c8ee1aacfef", null ]
];