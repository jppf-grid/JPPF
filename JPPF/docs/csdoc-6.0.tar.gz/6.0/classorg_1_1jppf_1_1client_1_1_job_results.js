var classorg_1_1jppf_1_1client_1_1_job_results =
[
    [ "JobResults", "classorg_1_1jppf_1_1client_1_1_job_results.html#a53538a046e9657b0cf2a510f5bb9af91", null ],
    [ "JobResults", "classorg_1_1jppf_1_1client_1_1_job_results.html#a8ce6ef835d4f96dd8edd69382bc1d283", null ],
    [ "addResults", "classorg_1_1jppf_1_1client_1_1_job_results.html#a1d779b02e597ed6e79794d9a976eaf91", null ],
    [ "clear", "classorg_1_1jppf_1_1client_1_1_job_results.html#a81ff6f7317f9b9f19406299dcaa36090", null ],
    [ "getAllResults", "classorg_1_1jppf_1_1client_1_1_job_results.html#a121ae63dd8143b39b1d4c74f5eaa3212", null ],
    [ "getResultsList", "classorg_1_1jppf_1_1client_1_1_job_results.html#a4455e3487afa5ecdf314f40fa233a4e5", null ],
    [ "getResultTask", "classorg_1_1jppf_1_1client_1_1_job_results.html#a882554ddf2ca48e8263e4f2e114b79e1", null ],
    [ "hasResult", "classorg_1_1jppf_1_1client_1_1_job_results.html#a0b9fdcb3c4eea3bc2644ec33dbf864b5", null ],
    [ "size", "classorg_1_1jppf_1_1client_1_1_job_results.html#a647b0d3ad2b702d10081304ab283e213", null ],
    [ "waitForTask", "classorg_1_1jppf_1_1client_1_1_job_results.html#a1e7a5a5f32efa90eb89c6e79d3bb157b", null ],
    [ "waitForTask", "classorg_1_1jppf_1_1client_1_1_job_results.html#a3d520e294d1bf2a955df97c6b31a1984", null ]
];