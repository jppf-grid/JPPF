var classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service =
[
    [ "JPPFCompletionService", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#a724ca06478df3c4b67c173edf27d39d3", null ],
    [ "JPPFCompletionService", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#a1d741869ec073cbaf85b98e9affd94d0", null ],
    [ "poll", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#a729ae319f9fae8109b3b7228f6071ce4", null ],
    [ "poll", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#a6983386dad35efa07625f758803241ac", null ],
    [ "submit", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#a60285c7c9d16c1a97db6776d2d0fe9bf", null ],
    [ "submit", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#af3f14f06bdaf97f18a0c30b26c7c9967", null ],
    [ "take", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_completion_service.html#afe7a10802d037567d5d8a27636833b36", null ]
];