var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event =
[
    [ "JobMonitoringEvent", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event.html#a567faabc11e724e7937816580c8296bc", null ],
    [ "getJob", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event.html#aa0922629a8e23528efa3ca8e65e4878c", null ],
    [ "getJobDispatch", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event.html#ad4f818757b0021b5ceea9c962c2404ec", null ],
    [ "getJobDriver", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event.html#a99cb022ec85f775218856696a52d4c91", null ],
    [ "getJobMonitor", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitoring_event.html#a038bc2a2875f4b0ea309652e45493397", null ]
];