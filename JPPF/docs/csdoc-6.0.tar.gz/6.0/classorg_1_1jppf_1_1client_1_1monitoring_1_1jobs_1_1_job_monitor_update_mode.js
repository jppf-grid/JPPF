var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode =
[
    [ "JobMonitorUpdateMode", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#ad579c4ee60d242e7c1f905a3aba5ea3c", null ],
    [ "valueOf", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#ac9b83830723e9f41b6c671302f8fcb33", null ],
    [ "values", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#a4093898cfdb6affd35f3d5a91c07ef20", null ],
    [ "DEFERRED_NOTIFICATIONS", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#ae5c4a235bc3970c699055bccbc1937f2", null ],
    [ "IMMEDIATE_NOTIFICATIONS", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#abb503b0029ca7dc21e42b46bd81a2d01", null ],
    [ "POLLING", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_monitor_update_mode.html#a9b01a3751fc23d8e7bbe99575dc36cff", null ]
];