var classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer =
[
    [ "DotnetSerializer", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#a3d01de5e51e811e473f80d0f3d82985a", null ],
    [ "Cancel", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#a3bb1679d956474bdf4fc4381e1017fca", null ],
    [ "Deserialize", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#ab29b4c49bd0640d55108ba337a2759a0", null ],
    [ "Execute", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#a53f0f7c0572160187facb7497970b9c3", null ],
    [ "Serialize", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#abdb379c22abde4f7d756dc05d404bc50", null ],
    [ "Timeout", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_serializer.html#a82188682c49f1e624f04673d1364b7bc", null ]
];