var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver =
[
    [ "JobDriver", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver.html#aaa78c5f6e95d071037f3a9179ccd88ff", null ],
    [ "getJob", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver.html#a1108c72cf89cd32fdbd4170c1cdf6a59", null ],
    [ "getJobManager", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver.html#a983d209783d6ee9e7a73b2a36e968375", null ],
    [ "getJobs", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver.html#a4828593f757bba225f5a5ed56c519bad", null ],
    [ "getTopologyDriver", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_driver.html#aa813bec72b1d3bfecd4c49c572e5d9fa", null ]
];