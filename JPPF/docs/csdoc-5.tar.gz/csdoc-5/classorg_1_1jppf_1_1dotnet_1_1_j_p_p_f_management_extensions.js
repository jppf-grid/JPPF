var classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_management_extensions =
[
    [ "AddNotificationListener", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_management_extensions.html#a3567465e763893c562fc977f7c93f5c3", null ],
    [ "RegisterFowrwardingNotificationListener", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_management_extensions.html#aa5d97ec28f5ab8b08da4a949f54b7bae", null ]
];