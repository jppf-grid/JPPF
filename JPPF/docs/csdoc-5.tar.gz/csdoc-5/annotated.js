var annotated =
[
    [ "event", "namespaceevent.html", "namespaceevent" ],
    [ "java", "namespacejava.html", "namespacejava" ],
    [ "javax", "namespacejavax.html", "namespacejavax" ],
    [ "org", "namespaceorg.html", "namespaceorg" ]
];