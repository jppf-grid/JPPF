var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job =
[
    [ "Job", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job.html#aa8b6500457a6f2e7ae716bbb211336b5", null ],
    [ "getJobDispatch", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job.html#a1135e73f256557c6053eb67ea4046088", null ],
    [ "getJobDispatches", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job.html#aaa0576260004202b82879a732413f38c", null ],
    [ "getJobDriver", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job.html#ad6b1dfba503fa199fd99de96effa0a02", null ],
    [ "getJobInformation", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job.html#a95d9f421e5328ee226e40d854249c6df", null ]
];