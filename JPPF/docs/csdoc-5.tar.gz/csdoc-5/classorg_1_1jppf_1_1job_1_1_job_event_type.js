var classorg_1_1jppf_1_1job_1_1_job_event_type =
[
    [ "JobEventType", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#a369c66b1bcac62a7c71171199a1d75d7", null ],
    [ "valueOf", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#ab483695e04b0857ee6e2f33b4c8e1800", null ],
    [ "values", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#aa69707b93f6d2be935fb43fddde414fd", null ],
    [ "JOB_DISPATCHED", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#a8e89ac3d410d247d6f41b7823874955f", null ],
    [ "JOB_ENDED", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#a71c2cddb8ce78ffbc215ec384e341707", null ],
    [ "JOB_QUEUED", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#a2731d5299c6f24c5a2a85dfe737d8680", null ],
    [ "JOB_RETURNED", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#aa61b74b4f3d2a710045eab4f7b32e9d0", null ],
    [ "JOB_UPDATED", "classorg_1_1jppf_1_1job_1_1_job_event_type.html#ae499d61627166a93a898cc860cd0f3d0", null ]
];