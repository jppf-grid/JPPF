var classevent_1_1_job_event =
[
    [ "JobEvent", "classevent_1_1_job_event.html#a8f1d037bb0eb67a18da245e06d41c83f", null ],
    [ "JobEvent", "classevent_1_1_job_event.html#aadb53e939cd6b80b73b69733ca9b7e9c", null ],
    [ "JobEvent", "classevent_1_1_job_event.html#aac45fdb4fb4950b2f8f71b4e28af75ea", null ],
    [ "getConnection", "classevent_1_1_job_event.html#ab7ff95976cd3fda664411df5ce66e678", null ],
    [ "getJob", "classevent_1_1_job_event.html#a9400471077e628be12b0becd3514f062", null ],
    [ "getJobTasks", "classevent_1_1_job_event.html#abb57c3be7f3d414d2fe849f9d51056a3", null ],
    [ "isRemoteExecution", "classevent_1_1_job_event.html#a2cfb1d37df7c310c31c8f605fc32d0d7", null ]
];