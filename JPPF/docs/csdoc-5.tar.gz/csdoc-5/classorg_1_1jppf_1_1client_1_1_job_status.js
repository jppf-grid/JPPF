var classorg_1_1jppf_1_1client_1_1_job_status =
[
    [ "JobStatus", "classorg_1_1jppf_1_1client_1_1_job_status.html#aca36542e16e7d244a47ae1cd5b5f05b0", null ],
    [ "valueOf", "classorg_1_1jppf_1_1client_1_1_job_status.html#a8f7648846eb6f0cdd5891aca0ce11ecd", null ],
    [ "values", "classorg_1_1jppf_1_1client_1_1_job_status.html#ac45e3ee5f112e974bb1fb13cfb4cd46c", null ],
    [ "COMPLETE", "classorg_1_1jppf_1_1client_1_1_job_status.html#a39db975b8c15cb42d325bca3fadfc22d", null ],
    [ "EXECUTING", "classorg_1_1jppf_1_1client_1_1_job_status.html#ab1c4e1d9112cc40b4da285c5d3b5f2f2", null ],
    [ "FAILED", "classorg_1_1jppf_1_1client_1_1_job_status.html#ab5e3aee8320e83caf128b5042378ee3b", null ],
    [ "PENDING", "classorg_1_1jppf_1_1client_1_1_job_status.html#adc391a0f702b7710828b48b05a4f0a6f", null ],
    [ "SUBMITTED", "classorg_1_1jppf_1_1client_1_1_job_status.html#a42e934b7a3c6ac10131bef3a1078665c", null ]
];