var classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher =
[
    [ "DotnetJobEventDispatcher", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#af9791b0fbbae1d0d1a3215d7a630236c", null ],
    [ "DotnetJobEventDispatcher", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#a01eb629968739a3b4e75d4f9cd143d6c", null ],
    [ "JobDispatched", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#a90b8eca30bbfbfd5ad9e4a851f429720", null ],
    [ "JobEnded", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#a2435d51a69f29c8c332a45b9af92e30b", null ],
    [ "JobReturned", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#a83809942bce20fc26e8593bb8488dd85", null ],
    [ "JobStarted", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_event_dispatcher.html#af0ff564dfb6f7250923c5c9e97ebedfe", null ]
];