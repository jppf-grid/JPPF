var classorg_1_1jppf_1_1job_1_1_job_notification =
[
    [ "JobNotification", "classorg_1_1jppf_1_1job_1_1_job_notification.html#a6165882845409afba36ca0259e52ce5e", null ],
    [ "JobNotification", "classorg_1_1jppf_1_1job_1_1_job_notification.html#a088f9b583c8d61bb9ccccaa12d5a895d", null ],
    [ "getEventType", "classorg_1_1jppf_1_1job_1_1_job_notification.html#ab4cf187f8ba6d9fa6fa8f208d9688f2e", null ],
    [ "getJobInformation", "classorg_1_1jppf_1_1job_1_1_job_notification.html#a0e75d195c1095164df23bc836657b4cc", null ],
    [ "getNodeInfo", "classorg_1_1jppf_1_1job_1_1_job_notification.html#ad8adf22538ccb4f35d56f7b5cbf080b0", null ]
];