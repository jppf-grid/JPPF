var classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_notification_listener =
[
    [ "BaseDotnetNotificationListener", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_notification_listener.html#a365c843d1ae0a1c908ec8e1ace00d7d6", null ],
    [ "HandleNotification", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_notification_listener.html#a84494685c6ef8d7e5d1495548ecbf4f9", null ]
];