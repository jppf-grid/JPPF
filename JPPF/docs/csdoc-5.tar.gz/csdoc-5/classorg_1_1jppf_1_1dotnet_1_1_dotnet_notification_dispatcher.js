var classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_dispatcher =
[
    [ "DotnetNotificationDispatcher", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_dispatcher.html#a05393576a3be1683b829f743ee99b04d", null ],
    [ "DotnetNotificationDispatcher", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_dispatcher.html#af60fabbc5e39a84049adc32fd59c9d28", null ],
    [ "HandleNotification", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_dispatcher.html#aec357039d7ea0905f1f08b7daef73c4b", null ]
];