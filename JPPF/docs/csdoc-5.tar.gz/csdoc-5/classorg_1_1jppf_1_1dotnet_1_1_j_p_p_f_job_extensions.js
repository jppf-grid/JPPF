var classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_job_extensions =
[
    [ "add", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_job_extensions.html#a4cda9a2e7c5ae1199fcb6f31b4d5c641", null ],
    [ "add", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_job_extensions.html#aa5f6d0995d45a65437d8ab36edf1fd94", null ],
    [ "addJobListener", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_job_extensions.html#a348ebd0e8f5f47c48ccdbb4d1c9a231d", null ]
];