var classorg_1_1jppf_1_1location_1_1_location_event =
[
    [ "LocationEvent", "classorg_1_1jppf_1_1location_1_1_location_event.html#a7e22a6e3bf639318f3d2681d8b4bf122", null ],
    [ "LocationEvent", "classorg_1_1jppf_1_1location_1_1_location_event.html#a282f7b90c0790ab009d8aec0836b2bcf", null ],
    [ "getLocation", "classorg_1_1jppf_1_1location_1_1_location_event.html#af820887cfeb4eb1d70e4b5df606c3375", null ],
    [ "getTransferredBytes", "classorg_1_1jppf_1_1location_1_1_location_event.html#a76e1221e8f5e0cc8babdc27f865e5c68", null ]
];