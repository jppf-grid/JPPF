var classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_dotnet =
[
    [ "Init", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_dotnet.html#a36aad7fa4a0e50947689ad35ffc9a67e", null ],
    [ "Init", "classorg_1_1jppf_1_1dotnet_1_1_j_p_p_f_dotnet.html#ae9efe455b3c4c3b0c37a171056eafe28", null ]
];