var classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future =
[
    [ "JPPFTaskFuture", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#ae2ea7e71f71ace9899b10dc2a0e93dd6", null ],
    [ "JPPFTaskFuture", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#a2f29b846f56a33353dbb31a4889bb9f8", null ],
    [ "cancel", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#afc8fe8f2a22715781190fd222f8f3575", null ],
    [ "get", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#ae1752420255d7f89bbeb8befe635e43b", null ],
    [ "get", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#afb5ca4884535a65b215e7fe3ca79d666", null ],
    [ "getJob", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#adfba216760909cfb3fb8cdc899455e19", null ],
    [ "getTask", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#ac50b74dd4f112e688c31fe44f30125b9", null ],
    [ "isCancelled", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#a69b4f52159fc30550d0493eaa01dc660", null ],
    [ "isDone", "classorg_1_1jppf_1_1client_1_1concurrent_1_1_j_p_p_f_task_future.html#abc4851e398750041e169a36adf3d699a", null ]
];