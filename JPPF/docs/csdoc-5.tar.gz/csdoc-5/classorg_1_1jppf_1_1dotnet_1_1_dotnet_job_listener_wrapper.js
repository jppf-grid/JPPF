var classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper =
[
    [ "DotnetJobListenerWrapper", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#aa034393d5f5f1fd2728748db9757f34c", null ],
    [ "DotnetJobListenerWrapper", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#af62921c5017c20f4d40015b8a4263c55", null ],
    [ "jobDispatched", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#aa95934db1fc06ab5d048d69d7839715d", null ],
    [ "jobEnded", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#af08bf397d0d15d5147778538da42684d", null ],
    [ "jobReturned", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#a5b72a76ba6a0b81723d140864f9cca7d", null ],
    [ "jobStarted", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_job_listener_wrapper.html#a23d70eb5396ba0db559bcb189af41df3", null ]
];