var classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job =
[
    [ "AbstractJPPFJob", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#a54f81f91112634bb0a74a8aff5b7155c", null ],
    [ "getCancelledFlag", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#aadbbb39801facc3e74ca0be1ced534f4", null ],
    [ "getMetadata", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#af25d27d6d8d1a38d6ed90a0e824ac82c", null ],
    [ "getName", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#aac595cf455672705614e145e34a00c1a", null ],
    [ "getResults", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#af650445e706022740571449ca1d1b035", null ],
    [ "getSLA", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#aacd3844d30aa96191df074defb6829af", null ],
    [ "getTaskCount", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#a39b1c46c9a7b86a44b03ada2f96057a1", null ],
    [ "getUuid", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#a5d523a7736ee926f5ae1adaddb0edc5e", null ],
    [ "setClientSLA", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#a43d9713846268ec721d3e7fc2772c5e8", null ],
    [ "setMetadata", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#a251b597125f947629f3cdc528a6cb57e", null ],
    [ "setSLA", "classorg_1_1jppf_1_1client_1_1_abstract_j_p_p_f_job.html#afccf31de20679b326cf45ee472cf5b64", null ]
];