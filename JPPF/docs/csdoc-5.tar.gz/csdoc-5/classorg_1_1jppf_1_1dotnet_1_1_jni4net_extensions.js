var classorg_1_1jppf_1_1dotnet_1_1_jni4net_extensions =
[
    [ "AddClassPaths", "classorg_1_1jppf_1_1dotnet_1_1_jni4net_extensions.html#a098b2b9901603826c70d8e10690bfa88", null ],
    [ "AddClassPaths", "classorg_1_1jppf_1_1dotnet_1_1_jni4net_extensions.html#af84ffbe12e8c4aab0469e42b6bc11a2e", null ]
];