var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_abstract_job_component =
[
    [ "AbstractJobComponent", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_abstract_job_component.html#aae04a8bb3c5a8a9c1f886fcce5b41df0", null ]
];