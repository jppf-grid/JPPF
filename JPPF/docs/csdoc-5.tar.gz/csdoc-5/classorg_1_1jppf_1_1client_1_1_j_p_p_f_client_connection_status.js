var classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status =
[
    [ "JPPFClientConnectionStatus", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a077a16e3de1892375c10737cdba2c0cb", null ],
    [ "isOneOf", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a9b0e9cb32df8f67d3126c940f2eef419", null ],
    [ "isTerminatedStatus", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#ab28ebe726592c4c813dc5e4a8066cb05", null ],
    [ "isWorkingStatus", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a60379372cbcdf269a2855be7c0a0528d", null ],
    [ "valueOf", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a31653a4f7317db67b0b42a9801e69dbe", null ],
    [ "values", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#ac46ca686a1583cc8a358c959168227f0", null ],
    [ "ACTIVE", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#af333efa051618995d7b43c4b334a5860", null ],
    [ "CLOSED", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#acae6c07be923bdcd10610c50e08b6a54", null ],
    [ "CONNECTING", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a01110aa32f601004f9b2255e973e26ea", null ],
    [ "CREATED", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a7cfae0643b4c80ee7cf72cb4918aac9f", null ],
    [ "DISCONNECTED", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#abfe498148eeec05c10004b7a555b01d7", null ],
    [ "EXECUTING", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a20bf186d681aa0c71002278a4721fa2a", null ],
    [ "FAILED", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#aff722d81dac959706a8d3eb6d08f6a79", null ],
    [ "NEW", "classorg_1_1jppf_1_1client_1_1_j_p_p_f_client_connection_status.html#a5309d3b48974c8adeb44bee10377224d", null ]
];