var classorg_1_1jppf_1_1job_1_1_job_information =
[
    [ "JobInformation", "classorg_1_1jppf_1_1job_1_1_job_information.html#af2dc234b73794a49c7b5ef3ad4fc6564", null ],
    [ "JobInformation", "classorg_1_1jppf_1_1job_1_1_job_information.html#a599519fcca5057ffee2f4218fc16af91", null ],
    [ "JobInformation", "classorg_1_1jppf_1_1job_1_1_job_information.html#ad789ec0750b386b262492fa3ddd71894", null ],
    [ "JobInformation", "classorg_1_1jppf_1_1job_1_1_job_information.html#a41292139e9bd2e11c10b4f8281ba70c3", null ],
    [ "getInitialTaskCount", "classorg_1_1jppf_1_1job_1_1_job_information.html#a280a9af39d677b15a5046f440a68d534", null ],
    [ "getJobName", "classorg_1_1jppf_1_1job_1_1_job_information.html#af57c8dac9a868412302742b438e1da81", null ],
    [ "getJobUuid", "classorg_1_1jppf_1_1job_1_1_job_information.html#a1e7d3c99bbf04a89431ad48b6c52cab6", null ],
    [ "getMaxNodes", "classorg_1_1jppf_1_1job_1_1_job_information.html#ade62b2335cc2ec7e6495adafa873b8a5", null ],
    [ "getPriority", "classorg_1_1jppf_1_1job_1_1_job_information.html#a57eadd8e358ac4d5f8579f83c6020cb1", null ],
    [ "getTaskCount", "classorg_1_1jppf_1_1job_1_1_job_information.html#adeb4fc8833ab56729c83d41161363dc5", null ],
    [ "isPending", "classorg_1_1jppf_1_1job_1_1_job_information.html#a8f0283b45fbe4a5fb4123d387f3393a8", null ],
    [ "isSuspended", "classorg_1_1jppf_1_1job_1_1_job_information.html#aaa0c7c3df0914c1cba404400864d23e7", null ],
    [ "setInitialTaskCount", "classorg_1_1jppf_1_1job_1_1_job_information.html#a13c423f3916c53ad8ef53a0834e8b33b", null ],
    [ "setJobName", "classorg_1_1jppf_1_1job_1_1_job_information.html#a2dd5a270fe0694b3d0ad90b6b96a1486", null ],
    [ "setJobUuid", "classorg_1_1jppf_1_1job_1_1_job_information.html#af0cfb0ff26ec674525d6aaeaedb8c02c", null ],
    [ "setMaxNodes", "classorg_1_1jppf_1_1job_1_1_job_information.html#a385e2ca0ffd6bd5e5a55c96aba038872", null ],
    [ "setPending", "classorg_1_1jppf_1_1job_1_1_job_information.html#a3957300e4fe4ef65b56ab9312c57207a", null ],
    [ "setPriority", "classorg_1_1jppf_1_1job_1_1_job_information.html#a339abecfc392ecce44f07fe891cae5de", null ],
    [ "setSuspended", "classorg_1_1jppf_1_1job_1_1_job_information.html#a1cc6ce28f50549b8c1cb96346859c80b", null ],
    [ "setTaskCount", "classorg_1_1jppf_1_1job_1_1_job_information.html#a1bb288b5105d911c75852a9d1d77daab", null ]
];