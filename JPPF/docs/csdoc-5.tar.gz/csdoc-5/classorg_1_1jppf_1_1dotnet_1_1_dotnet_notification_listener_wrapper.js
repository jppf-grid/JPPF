var classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_listener_wrapper =
[
    [ "DotnetNotificationListenerWrapper", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_listener_wrapper.html#af29609b2bec0b2e3bbac4a0ab8238cd5", null ],
    [ "DotnetNotificationListenerWrapper", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_listener_wrapper.html#aeafc220937b46ad310617700eec23692", null ],
    [ "handleNotification", "classorg_1_1jppf_1_1dotnet_1_1_dotnet_notification_listener_wrapper.html#ad9c40724d5a58dd721303bfd1818409f", null ]
];