var classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener =
[
    [ "BaseDotnetJobListener", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener.html#a167d990d5446f695370a65304ceeecd3", null ],
    [ "JobDispatched", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener.html#a1131cda0fecc119cf586369fd5d64fca", null ],
    [ "JobEnded", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener.html#aeb56ebb5cdc34d7c074b1e1b92bd6fe1", null ],
    [ "JobReturned", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener.html#ad8d3d565d762c7c6655201f897807dca", null ],
    [ "JobStarted", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_job_listener.html#a8bad8336da949e5c334ccb17f5e38356", null ]
];