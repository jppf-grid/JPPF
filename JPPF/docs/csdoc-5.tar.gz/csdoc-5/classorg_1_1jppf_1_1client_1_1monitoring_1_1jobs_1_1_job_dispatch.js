var classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_dispatch =
[
    [ "JobDispatch", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_dispatch.html#ae09035f0498893bea670640747781623", null ],
    [ "getJob", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_dispatch.html#a49b9e3d4365f3b299051a4b192b9f84a", null ],
    [ "getJobInformation", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_dispatch.html#a52a0c4ed6f9ec30a84a39d61ba85c5e1", null ],
    [ "getNode", "classorg_1_1jppf_1_1client_1_1monitoring_1_1jobs_1_1_job_dispatch.html#a82c97299ba8fb930356cba2bb0a3c203", null ]
];