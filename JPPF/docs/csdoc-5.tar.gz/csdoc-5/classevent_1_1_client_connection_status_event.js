var classevent_1_1_client_connection_status_event =
[
    [ "ClientConnectionStatusEvent", "classevent_1_1_client_connection_status_event.html#a008582ecad0e2d8191748badc1abaaf2", null ],
    [ "ClientConnectionStatusEvent", "classevent_1_1_client_connection_status_event.html#a240204f1edd93d64c0f6d2ea480b0009", null ],
    [ "getClientConnectionStatusHandler", "classevent_1_1_client_connection_status_event.html#a1264b754f36a7a607a52158af8c2fed5", null ],
    [ "getOldStatus", "classevent_1_1_client_connection_status_event.html#a9efb09bf8b061c1eb5cf2b4b7327feff", null ]
];