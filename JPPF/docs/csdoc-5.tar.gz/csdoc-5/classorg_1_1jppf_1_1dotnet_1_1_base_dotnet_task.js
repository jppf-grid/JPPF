var classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task =
[
    [ "BaseDotnetTask", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#ad9b77dbd53c34e70eaf3a5e7348a572f", null ],
    [ "Execute", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#aba7d224b616a0b8bb104b253b663bef9", null ],
    [ "OnCancel", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#a32ba9e92f9838746e49ae83871c19013", null ],
    [ "OnTimeout", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#a4e5c2a7bc6f4c8135eae7aaace16de41", null ],
    [ "Cancelled", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#a0d4cf12a77e17f7a282d21e0ae9b3679", null ],
    [ "Exception", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#a1db49088200997bf220f25b868decf5d", null ],
    [ "Result", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#aa996bda5c72d2b3fd11bbc19b5ee72b4", null ],
    [ "TimedOut", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#a1c682401a751e4feb4f205d765a26930", null ],
    [ "TimeoutSchedule", "classorg_1_1jppf_1_1dotnet_1_1_base_dotnet_task.html#af9767c93544d22007eb71858bc029055", null ]
];